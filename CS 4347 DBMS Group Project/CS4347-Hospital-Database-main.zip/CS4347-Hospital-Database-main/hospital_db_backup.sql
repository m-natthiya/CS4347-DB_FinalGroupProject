--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Postgres.app)
-- Dumped by pg_dump version 16.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: appointment_status; Type: TYPE; Schema: public; Owner: aj
--

CREATE TYPE public.appointment_status AS ENUM (
    'Pending',
    'Confirmed',
    'Cancelled'
);


ALTER TYPE public.appointment_status OWNER TO aj;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: aj
--

CREATE TABLE public.appointments (
    appointment_id integer NOT NULL,
    patient_id integer,
    staff_id integer,
    appointment_date timestamp without time zone NOT NULL,
    reason_for_visit text,
    status public.appointment_status
);


ALTER TABLE public.appointments OWNER TO aj;

--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: aj
--

CREATE SEQUENCE public.appointments_appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_appointment_id_seq OWNER TO aj;

--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aj
--

ALTER SEQUENCE public.appointments_appointment_id_seq OWNED BY public.appointments.appointment_id;


--
-- Name: appointments_appointment_id_seq1; Type: SEQUENCE; Schema: public; Owner: aj
--

ALTER TABLE public.appointments ALTER COLUMN appointment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.appointments_appointment_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: billing; Type: TABLE; Schema: public; Owner: aj
--

CREATE TABLE public.billing (
    billing_id integer NOT NULL,
    patient_id integer,
    amount_due numeric(10,2) NOT NULL,
    payment_status character varying(50) NOT NULL,
    billing_date timestamp without time zone NOT NULL,
    insurance_coverage character varying(255),
    payment_received numeric(10,2) DEFAULT 0,
    outstanding_balance numeric(10,2) DEFAULT 0
);


ALTER TABLE public.billing OWNER TO aj;

--
-- Name: billing_billing_id_seq; Type: SEQUENCE; Schema: public; Owner: aj
--

CREATE SEQUENCE public.billing_billing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_billing_id_seq OWNER TO aj;

--
-- Name: billing_billing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aj
--

ALTER SEQUENCE public.billing_billing_id_seq OWNED BY public.billing.billing_id;


--
-- Name: billing_billing_id_seq1; Type: SEQUENCE; Schema: public; Owner: aj
--

ALTER TABLE public.billing ALTER COLUMN billing_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.billing_billing_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: medical_records; Type: TABLE; Schema: public; Owner: aj
--

CREATE TABLE public.medical_records (
    record_id integer NOT NULL,
    patient_id integer,
    diagnosis text NOT NULL,
    treatment text NOT NULL,
    doctor_notes text,
    medications text,
    record_date date NOT NULL
);


ALTER TABLE public.medical_records OWNER TO aj;

--
-- Name: medical_records_record_id_seq; Type: SEQUENCE; Schema: public; Owner: aj
--

CREATE SEQUENCE public.medical_records_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medical_records_record_id_seq OWNER TO aj;

--
-- Name: medical_records_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aj
--

ALTER SEQUENCE public.medical_records_record_id_seq OWNED BY public.medical_records.record_id;


--
-- Name: medical_records_record_id_seq1; Type: SEQUENCE; Schema: public; Owner: aj
--

ALTER TABLE public.medical_records ALTER COLUMN record_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.medical_records_record_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: patients; Type: TABLE; Schema: public; Owner: aj
--

CREATE TABLE public.patients (
    patient_id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(50) NOT NULL,
    contact_info text NOT NULL,
    address text NOT NULL,
    insurance_info text,
    medical_history text
);


ALTER TABLE public.patients OWNER TO aj;

--
-- Name: patients_patient_id_seq; Type: SEQUENCE; Schema: public; Owner: aj
--

CREATE SEQUENCE public.patients_patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patients_patient_id_seq OWNER TO aj;

--
-- Name: patients_patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aj
--

ALTER SEQUENCE public.patients_patient_id_seq OWNED BY public.patients.patient_id;


--
-- Name: patients_patient_id_seq1; Type: SEQUENCE; Schema: public; Owner: aj
--

ALTER TABLE public.patients ALTER COLUMN patient_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.patients_patient_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: aj
--

CREATE TABLE public.staff (
    staff_id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    "position" character varying(100) NOT NULL,
    contact_info character varying(100),
    hire_date date NOT NULL
);


ALTER TABLE public.staff OWNER TO aj;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: aj
--

CREATE SEQUENCE public.staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_staff_id_seq OWNER TO aj;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aj
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: staff_staff_id_seq1; Type: SEQUENCE; Schema: public; Owner: aj
--

ALTER TABLE public.staff ALTER COLUMN staff_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.staff_staff_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: aj
--

COPY public.appointments (appointment_id, patient_id, staff_id, appointment_date, reason_for_visit, status) FROM stdin;
1	4	1	2024-11-28 09:30:00	Throat	Pending
2	4	1	2024-11-29 10:15:00	Ribs	Pending
4	1	1	2024-12-05 10:15:00	Ribs	Pending
3	4	1	2024-12-04 12:15:00	Head Injury	Confirmed
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: aj
--

COPY public.billing (billing_id, patient_id, amount_due, payment_status, billing_date, insurance_coverage, payment_received, outstanding_balance) FROM stdin;
1	1	320.00	Pending	2024-11-19 00:00:00	300.00	20.00	0.00
2	1	40.00	Paid	2024-11-20 00:00:00	40.00	40.00	0.00
3	4	450.00	Pending	2024-11-07 00:00:00	400.00	50.00	0.00
4	4	3200.00	Paid	2024-11-19 00:00:00	3000.00	200.00	0.00
5	1	3200.00	Pending	2024-11-04 00:00:00	3000.00	200.00	0.00
\.


--
-- Data for Name: medical_records; Type: TABLE DATA; Schema: public; Owner: aj
--

COPY public.medical_records (record_id, patient_id, diagnosis, treatment, doctor_notes, medications, record_date) FROM stdin;
3	4	Hernia	4 weeks rest	sports	na	2024-11-28
4	7	fractured ankle	walking boot	N/A	Tylenol	2024-09-24
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: aj
--

COPY public.patients (patient_id, first_name, last_name, date_of_birth, gender, contact_info, address, insurance_info, medical_history) FROM stdin;
4	Hinata	Yuziki	2024-11-12	Female	1234567890	123 Main Street	Blue Cross Blue Shield	none
7	AJ	Kimbrough	2024-11-16	Female	1234567890	3427 Cedar Springs Rd	Blue Cross Blue Shield	fractured ribs
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: aj
--

COPY public.staff (staff_id, first_name, last_name, "position", contact_info, hire_date) FROM stdin;
1	Joy	Doe	Nurse	1231231231	2024-11-11
2	Shay	Niles	Nurse	12121212121	2024-11-04
3	John	Doe	Physician	4332398917	2024-11-01
4	Jane	Doe	Nuero	1234567890	2024-11-04
\.


--
-- Name: appointments_appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.appointments_appointment_id_seq', 7, true);


--
-- Name: appointments_appointment_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.appointments_appointment_id_seq1', 7, true);


--
-- Name: billing_billing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.billing_billing_id_seq', 1, false);


--
-- Name: billing_billing_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.billing_billing_id_seq1', 5, true);


--
-- Name: medical_records_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.medical_records_record_id_seq', 1, false);


--
-- Name: medical_records_record_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.medical_records_record_id_seq1', 5, true);


--
-- Name: patients_patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.patients_patient_id_seq', 1, false);


--
-- Name: patients_patient_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.patients_patient_id_seq1', 9, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 1, true);


--
-- Name: staff_staff_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: aj
--

SELECT pg_catalog.setval('public.staff_staff_id_seq1', 4, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointment_id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (billing_id);


--
-- Name: medical_records medical_records_pkey; Type: CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.medical_records
    ADD CONSTRAINT medical_records_pkey PRIMARY KEY (record_id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (patient_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: appointments appointments_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aj
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- PostgreSQL database dump complete
--

