Read Me for the Create Table Instructions

1. Install the SQL program and connect to the server.
2. Open the create.sql file.
3. Select the schema: TaskC.
4. Click Execute. The Result Grid will appear at the bottom.
Note: You can modify or add data to the table as shown in the Result Grid, then click Execute again to apply the changes.
5. Click Export to generate the output as a CSV or Excel file.


Read Me for Loading Data Instructions

1. Install the SQL program and connect to the server.
2. Save Patient_data.csv to your SQL library on your computer.
3. Open the load.sql file.
4. Select the schema: Loaddata.
5. Click Execute. The Result Grid will appear at the bottom.
6. Click Export to generate the output as a CSV or Excel file.