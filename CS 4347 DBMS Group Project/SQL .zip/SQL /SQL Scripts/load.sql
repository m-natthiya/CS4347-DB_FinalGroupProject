CREATE DATABASE IF NOT EXISTS Loaddata;

USE Loaddata;

DROP TABLE IF EXISTS Patients_data;

CREATE TABLE Patients_data
(	Patient_id INT PRIMARY KEY,
    First_name VARCHAR(255),
    Last_name VARCHAR(255),
    Date_of_birth DATE,
    Gender VARCHAR(255),
    Contact_info VARCHAR(255),
    Address VARCHAR(255),
    Insurance_info VARCHAR(255),
    Medical_history TEXT
);

SELECT * FROM Patients_data;


LOAD DATA INFILE 'Patient_data.csv' INTO TABLE Patients_data
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

SELECT * FROM Patients_data
