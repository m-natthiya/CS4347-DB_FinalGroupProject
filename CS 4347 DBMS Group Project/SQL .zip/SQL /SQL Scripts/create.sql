SELECT * FROM TaskC.Patients;

SELECT * FROM TaskC.Staff;

SELECT * FROM TaskC.Appointments;

SELECT * FROM TaskC.Medical_Records;

SELECT * FROM TaskC.Billing;

SELECT Billing_id FROM TaskC.Billing;
ALTER TABLE TaskC.Billing MODIFY Billing_id INT AUTO_INCREMENT;

INSERT INTO TaskC.Billing (Billing_id, Patient_id, Total_cost, Insurance, Coverage, Payment_received, 
Outstanding_balance, Billing_date)
VALUES (1, 1, 300, 'Cigna', 0.90, 0.9 * 300, 300 - (0.9 * 300), '2024-01-10');

INSERT INTO TaskC.Billing (Billing_id, Patient_id, Total_cost, Insurance, Coverage, Payment_received, 
Outstanding_balance, Billing_date) 
VALUES (2, 2, 500, 'Atena', 0.80, 0.8 * 500 , 500 - (0.9 * 500), '2024-03-15');


